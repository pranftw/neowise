# neowise

### A Deep Learning library built from scratch with Python and NumPy